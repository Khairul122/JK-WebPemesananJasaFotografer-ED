	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="#"><i class="fa fa-exchange"></i>Transaksi</a>
					<ul class="ts-sidebar-menu">
						<li><a href="trx_bayar.php">Menunggu Pembayaran</a></li>				  						
						<li><a href="trx_konfirmasi.php">Menunggu Konfirmasi</a></li>
						<li><a href="trx.php">Data Transaksi</a></li>
                    </ul>
				</li>
				<li><a href="jadwal.php"><i class="fa fa-book"></i> Jadwal Hari Ini</a></li>
				<li><a href="paket.php"><i class="fa fa-cart-plus"></i> Paket</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i> Member</a></li>
				<li><a href="gallery.php"><i class="fa fa-users"></i> Gellery</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-phone"></i> Menghubungi</a></li>
				<li><a href="manage-pages.php"><i class="fa fa-gear"></i> Kelola Halaman</a></li>
				<li><a href="update-contactinfo.php"><i class="fa fa-info"></i>  &nbsp;&nbsp;Kontak Info</a></li>
				<li><a href="laporan.php"><i class="fa fa-files-o"></i> Laporan</a></li>
			</ul>
	</nav>